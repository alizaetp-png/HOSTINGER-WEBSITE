Upload this ZIP as-is. Do not unzip and re-zip a parent folder.
package.json is at the root of this archive.

Hostinger wizard:
  Framework: Other
  Node: 22
  Startup file: start-production.mjs
  Install: npm install
  Build: npm run build
  Start: npm start

Environment:
  NODE_ENV=production
  HOST=0.0.0.0
  NITRO_PRESET=node-server
  VITE_SITE_URL=https://skylineropetech.com.sg
