#!/usr/bin/env node
/**
 * Pack the Skyline Rope Tech site as a Hostinger Node.js zip
 * (same layout as the SteadyReno Hostinger Node sample).
 */
import {
  cpSync,
  existsSync,
  mkdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const STAGE = join(ROOT, "artifacts", "skyline-hostinger-stage");
const ZIP = join(ROOT, "artifacts", "Skyline-Rope-Tech-Hostinger.zip");

const COPY = [
  "package.json",
  "package-lock.json",
  "start-production.mjs",
  "HOSTINGER-DEPLOY.txt",
  ".htaccess",
  ".nvmrc",
  "tsconfig.json",
  "vite.config.ts",
  "eslint.config.mjs",
  "src",
  "public",
  "server",
  "scripts",
  "migrations",
];

function run(cmd, args, extraEnv = {}) {
  const r = spawnSync(cmd, args, {
    cwd: ROOT,
    encoding: "utf8",
    env: { ...process.env, ...extraEnv },
    timeout: 240000,
  });
  if (r.status !== 0) {
    throw new Error(`${cmd} ${args.join(" ")} failed:\n${r.stdout}\n${r.stderr}`);
  }
  return r;
}

if (process.env.SKIP_BUILD !== "1") {
  console.log("Building with NITRO_PRESET=node-server…");
  run("npm", ["run", "build:hostinger"], { NITRO_PRESET: "node-server" });
}

rmSync(STAGE, { recursive: true, force: true });
mkdirSync(STAGE, { recursive: true });

for (const item of COPY) {
  const from = join(ROOT, item);
  if (!existsSync(from)) continue;
  cpSync(from, join(STAGE, item), { recursive: true });
}

if (existsSync(join(ROOT, ".output"))) {
  cpSync(join(ROOT, ".output"), join(STAGE, ".output"), { recursive: true });
}

writeFileSync(
  join(STAGE, "README-UPLOAD.txt"),
  "Upload this folder to Hostinger. Read HOSTINGER-DEPLOY.txt first.\n",
);

rmSync(ZIP, { force: true });
const py = [
  "import zipfile, os",
  `root = ${JSON.stringify(STAGE)}`,
  `out = ${JSON.stringify(ZIP)}`,
  "with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:",
  "    for dirpath, dirs, files in os.walk(root):",
  "        dirs[:] = [d for d in dirs if d not in ('node_modules', '.git')]",
  "        for f in files:",
  "            p = os.path.join(dirpath, f)",
  "            z.write(p, os.path.relpath(p, root))",
  "print('wrote', out, os.path.getsize(out))",
].join("\n");
run("python3", ["-c", py]);
console.log("Hostinger zip:", ZIP);
