import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/layout";
import { StatCounters } from "@/components/site/stat-counters";
import { ProcessTimeline } from "@/components/site/process-timeline";
import { JsonLd } from "@/components/site/json-ld";
import { HeroBanner } from "@/components/site/hero-banner";
import { CredentialBadges } from "@/components/site/badges";
import { Reveal } from "@/components/site/reveal";
import { waUrl } from "@/lib/site";
import { homeCards, homeFaqs, whyPoints, projects } from "@/lib/content";
import { Photo } from "@/components/site/photo";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () =>
    pageHead({
      title: "Rope Access & BCA Façade Inspection SG | Skyline Rope Tech",
      description:
        "Certified rope access in Singapore for BCA façade inspection, seepage, waterproofing, paint, glass and roofs. 24/7 crew. WhatsApp +65 8302 0783.",
      path: "/",
      preloadImage: "/images/opt/web-hero-crew-1400.webp",
    }),
  component: Home,
});

function Home() {
  return (
    <SiteLayout current="/">
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: homeFaqs.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }}
      />

      <HeroBanner />
      <StatCounters />

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Who we work for
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Same crew. Two ways in.
          </h2>
          <p className="mt-2 max-w-2xl text-muted">
            Everyone who owns or runs a building in Singapore uses one of these
            doors. The technicians, the method and the warranty do not change.
          </p>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <article className="rounded-xl border border-line bg-paper p-7">
              <p className="text-xs font-extrabold tracking-[0.14em] text-teal-d uppercase">
                Residential
              </p>
              <h3 className="mt-2 text-xl font-bold">Home, condo & MCST</h3>
              <p className="mt-2 text-muted">
                Ceiling stain, failed sealant, council deadline, Periodic Façade
                Inspection. We survey the elevation, write the method and hand you
                a file the Tuesday meeting can keep.
              </p>
              <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-ink-soft">
                <li>External wall seepage and reseal</li>
                <li>BCA PFI access and photo record</li>
                <li>Paint, glass, roof and cladding rectification</li>
              </ul>
              <Link
                to="/mcst"
                className="mt-5 inline-block font-extrabold text-teal-d"
              >
                MCST & homeowners →
              </Link>
            </article>
            <article className="rounded-xl border border-line bg-paper p-7">
              <p className="text-xs font-extrabold tracking-[0.14em] text-teal-d uppercase">
                Occupied buildings
              </p>
              <h3 className="mt-2 text-xl font-bold">Commercial & industrial</h3>
              <p className="mt-2 text-muted">
                Occupied tower, mall or plant. Rope access keeps the driveway
                open. One contractor from PFI through rectification — no second
                crew to chase the punch list.
              </p>
              <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-ink-soft">
                <li>PFI close-up after the drone pass</li>
                <li>Night or occupied-hour programmes</li>
                <li>Glass, signage, lighting and roof works</li>
              </ul>
              <Link
                to="/services/$slug"
                params={{ slug: "bca-periodic-facade-inspection" }}
                className="mt-5 inline-block font-extrabold text-teal-d"
              >
                PFI & facilities →
              </Link>
            </article>
          </div>
        </Reveal>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            On the ropes
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            The work we take
          </h2>
          <p className="mt-2 max-w-2xl text-muted">
            Rope access is how we reach the job. The pages below are the job
            itself — each photo is a different Skyline elevation.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {homeCards.map((s) => (
              <Link
                key={s.slug}
                to="/services/$slug"
                params={{ slug: s.slug }}
                className="group overflow-hidden rounded-xl border border-line bg-card transition-transform duration-200 hover:-translate-y-0.5"
              >
                <Photo
                  src={s.image}
                  alt={s.imageAlt}
                  width={800}
                  height={533}
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="h-48 w-full object-cover"
                />
                <div className="p-5">
                  <h3 className="font-bold">{s.title}</h3>
                  <p className="mt-1 text-sm text-muted">{s.lead}</p>
                  <span className="mt-3 inline-block text-sm font-extrabold text-teal-d">
                    {s.nav} →
                  </span>
                </div>
              </Link>
            ))}
          </div>
          <Button asChild variant="outline" className="mt-8">
            <Link to="/services">See every service</Link>
          </Button>
        </Reveal>
      </section>

      <section className="border-y border-line bg-sky">
        <Reveal>
          <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-12 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
                Not sure if it is seepage, PFI or paint?
              </h2>
              <p className="mt-2 max-w-xl text-ink-soft">
                Send the stain, the council letter or the bay number. We tell you
                what the elevation actually needs — and whether ropes are the
                right tool.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="wa" size="lg">
                <a href={waUrl()} target="_blank" rel="noopener noreferrer">
                  WhatsApp a photo
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/guides/rope-access-vs-scaffolding">
                  Rope vs scaffold
                </Link>
              </Button>
            </div>
          </div>
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            How we work
          </p>
          <h2 className="mt-2 max-w-xl text-3xl font-bold tracking-tight sm:text-4xl">
            From first call to a file the building can keep.
          </h2>
          <p className="mt-3 max-w-2xl text-muted">
            Five steps. The line fills as you read. The photo on the right is
            the step you are on — already loaded, so it does not hitch.
          </p>
          <ProcessTimeline />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Why Skyline
          </p>
          <h2 className="mt-2 max-w-xl text-3xl font-bold tracking-tight sm:text-4xl">
            A crew that lives on the elevation.
          </h2>
          <div className="mt-8 grid gap-8 lg:grid-cols-2">
            <Photo
              src="/images/web/about-atrium.jpg"
              alt="Skyline Rope Tech rope access technicians on ropes inside a multi-storey Singapore atrium"
              width={800}
              height={1400}
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="h-72 w-full rounded-xl object-cover sm:h-[420px]"
            />
            <div className="grid gap-5">
              {whyPoints.map((w) => (
                <div key={w.title}>
                  <h3 className="font-bold">{w.title}</h3>
                  <p className="mt-1 text-muted">{w.body}</p>
                </div>
              ))}
              <Link to="/about" className="font-extrabold text-teal-d">
                About the company →
              </Link>
            </div>
          </div>
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <Reveal>
            <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
              Credentials
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight">
              The badges that sit on the method statement.
            </h2>
            <p className="mt-2 max-w-2xl text-muted">
              Rope access on the line. BCA Periodic Façade Inspection access. bizSAFE
              Level 3 on the safety system. Not a footer afterthought — the
              reason the council lets us on the roof.
            </p>
            <div className="mt-8">
              <CredentialBadges />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            On site
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Recent elevations
          </h2>
          <p className="mt-2 max-w-2xl text-muted">
            Named buildings can be added when you release them. These shots are
            Skyline jobs — not a stock library.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p) => (
              <article
                key={p.title}
                className="relative min-h-64 overflow-hidden rounded-xl text-primary-foreground"
              >
                <Photo
                  src={p.image}
                  alt={p.alt}
                  width={800}
                  height={600}
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="absolute inset-0 size-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 to-transparent" />
                <div className="absolute inset-x-4 bottom-4">
                  <p className="text-xs font-bold tracking-wide uppercase">{p.tag}</p>
                  <h3 className="text-lg font-bold">{p.title}</h3>
                </div>
              </article>
            ))}
          </div>
          <Button asChild variant="outline" className="mt-8">
            <Link to="/projects">All projects</Link>
          </Button>
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
          <Reveal>
            <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
              Before you call
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
              Quick answers
            </h2>
            <div className="mt-8 divide-y divide-line border-y border-line">
              {homeFaqs.map((f) => (
                <details key={f.q} className="py-4">
                  <summary className="cursor-pointer font-extrabold">{f.q}</summary>
                  <p className="mt-2 text-muted">{f.a}</p>
                </details>
              ))}
            </div>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}
