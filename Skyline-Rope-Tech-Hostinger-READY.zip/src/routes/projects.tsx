import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/layout";
import { projects } from "@/lib/content";
import { pageHead } from "@/lib/seo";
import { Photo } from "@/components/site/photo";

export const Route = createFileRoute("/projects")({
  head: () =>
    pageHead({
      title: "Rope Access Projects Singapore | Skyline Rope Tech",
      description:
        "Selected Skyline Rope Tech work: façades, roofs, glass, seepage and cleaning across Singapore. Real site photographs.",
      path: "/projects",
    }),
  component: Projects,
});

function Projects() {
  return (
    <SiteLayout current="/projects">
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Rope access projects Singapore
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">
            The work, not a stock library.
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">
            Each image is a different Skyline job. Named buildings can be added
            when you release them.
          </p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-12 sm:grid-cols-2 sm:px-6">
        {projects.map((p) => (
          <article
            key={p.title}
            className="relative min-h-64 overflow-hidden rounded-xl text-primary-foreground"
          >
            <Photo
              src={p.image}
              alt={p.alt}
              width={1400}
              height={900}
              sizes="(max-width: 640px) 100vw, 50vw"
              className="absolute inset-0 size-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/90 to-transparent" />
            <div className="absolute inset-x-4 bottom-4">
              <p className="text-xs font-bold tracking-wide uppercase">{p.tag}</p>
              <h2 className="text-xl font-bold">{p.title}</h2>
            </div>
          </article>
        ))}
      </section>
    </SiteLayout>
  );
}
