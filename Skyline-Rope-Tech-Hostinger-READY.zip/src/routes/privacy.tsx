import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/layout";
import { SITE, mailUrl } from "@/lib/site";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/privacy")({
  head: () =>
    pageHead({
      title: "Privacy Policy | Skyline Rope Tech",
      description:
        "How Skyline Rope Tech Pte Ltd collects and uses enquiry details in Singapore. Contact, WhatsApp and site-survey requests under the PDPA.",
      path: "/privacy",
    }),
  component: Privacy,
});

function Privacy() {
  return (
    <SiteLayout>
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Legal
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Privacy policy
          </h1>
          <p className="mt-3 text-ink-soft">
            Skyline Rope Tech Pte Ltd (UEN {SITE.uen}) collects only what is
            needed to answer a site survey or commercial enquiry in Singapore.
          </p>
        </div>
      </section>
      <section className="mx-auto max-w-3xl space-y-6 px-4 py-12 text-ink-soft sm:px-6">
        <p>
          When you use the contact form, email {SITE.email}, call{" "}
          {SITE.phoneDisplay} or WhatsApp, we receive the name, number, email
          and building details you send so we can reply and plan access.
        </p>
        <p>
          We do not sell that information. It is used to quote, schedule and
          follow up the job. Messages stay with the crew that needs them.
        </p>
        <p>
          The site uses standard hosting and security logs. We do not run
          advertising pixels on these pages.
        </p>
        <p>
          To ask what we hold or request a correction, email{" "}
          <a className="font-semibold text-teal-d underline" href={mailUrl()}>
            {SITE.email}
          </a>{" "}
          or write to {SITE.addressLine}, {SITE.city} {SITE.postal}.
        </p>
        <p>
          <Link to="/contact" className="font-semibold text-teal-d underline">
            Contact
          </Link>{" "}
          if this page does not answer your question.
        </p>
      </section>
    </SiteLayout>
  );
}
