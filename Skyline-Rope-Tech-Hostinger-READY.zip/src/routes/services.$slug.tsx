import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/layout";
import { BreadcrumbLd, JsonLd } from "@/components/site/json-ld";
import { BUSINESS_ID, SITE, waUrl } from "@/lib/site";
import { serviceBySlug, services } from "@/lib/content";
import { pageHead } from "@/lib/seo";
import { Photo } from "@/components/site/photo";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const s = serviceBySlug(params.slug);
    if (!s) throw notFound();
    return s;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return pageHead({
        title: "Service | Skyline Rope Tech",
        description: "Rope access services in Singapore.",
        path: "/services",
      });
    }
    return pageHead({
      title: loaderData.metaTitle,
      description: loaderData.metaDescription,
      path: loaderData.path,
    });
  },
  component: ServicePage,
});

function ServicePage() {
  const s = Route.useLoaderData();
  const others = services.filter((x) => x.slug !== s.slug).slice(0, 3);

  return (
    <SiteLayout current="/services">
      <BreadcrumbLd
        items={[
          { name: "Home", path: "/" },
          { name: "Services", path: "/services" },
          { name: s.nav, path: s.path },
        ]}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Service",
          name: s.h1,
          description: s.metaDescription,
          provider: { "@id": BUSINESS_ID, "@type": "GeneralContractor", name: SITE.name },
          areaServed: "Singapore",
          url: `https://skylineropetech.com.sg${s.path}`,
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: s.faqs.map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
        }}
      />
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            {s.kicker} · Singapore
          </p>
          <h1 className="mt-2 max-w-[18ch] text-3xl font-extrabold tracking-tight sm:text-4xl">
            {s.h1}
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">{s.lead}</p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-8 px-4 py-12 lg:grid-cols-[1.1fr_0.9fr] sm:px-6">
        <div>
          {s.body.map((p) => (
            <p key={p.slice(0, 24)} className="mb-4 text-ink-soft">
              {p}
            </p>
          ))}
          <h2 className="mt-8 text-2xl font-bold">Where this work sits</h2>
          <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">
            {s.bullets.map((b) => (
              <li key={b}>{b}</li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="wa" size="lg">
              <a href={waUrl(s.waText)} target="_blank" rel="noopener noreferrer">
                WhatsApp {SITE.phoneDisplay}
              </a>
            </Button>
            <Button asChild size="lg">
              <Link to="/contact">Request a survey</Link>
            </Button>
          </div>
          <h2 className="mt-12 text-2xl font-bold">Common questions</h2>
          <div className="mt-3 divide-y divide-line">
            {s.faqs.map((f) => (
              <details key={f.q} className="py-3">
                <summary className="cursor-pointer font-extrabold">{f.q}</summary>
                <p className="mt-2 text-muted">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
        <div className="grid gap-4">
          <Photo
            src={s.image}
            alt={s.imageAlt}
            width={1400}
            height={1050}
            sizes="(max-width: 1024px) 100vw, 50vw"
            className="max-h-[420px] w-full rounded-xl object-cover"
            priority
          />
          {s.extraImage ? (
            <Photo
              src={s.extraImage}
              alt={s.extraAlt ?? s.imageAlt}
              width={1400}
              height={1050}
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="max-h-[360px] w-full rounded-xl object-cover"
            />
          ) : null}
        </div>
      </section>
      <section className="border-t border-line bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
          <h2 className="text-xl font-bold">Related work</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            {others.map((o) => (
              <Link
                key={o.slug}
                to="/services/$slug"
                params={{ slug: o.slug }}
                className="overflow-hidden rounded-xl border border-line bg-card"
              >
                <Photo
                  src={o.image}
                  alt={o.imageAlt}
                  width={800}
                  height={400}
                  sizes="(max-width: 640px) 100vw, 33vw"
                  className="h-36 w-full object-cover"
                />
                <p className="p-4 font-semibold">{o.title}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
