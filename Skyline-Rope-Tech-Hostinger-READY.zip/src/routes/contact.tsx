import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/layout";
import { EnquiryForm } from "@/components/site/enquiry-form";
import { SITE, waUrl, mailUrl, telUrl } from "@/lib/site";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () =>
    pageHead({
      title: "Contact Skyline Rope Tech | WhatsApp +65 8302 0783",
      description:
        "WhatsApp Skyline Rope Tech on +65 8302 0783 or email info@skylineropetech.com.sg. 24/7. 30 Defu Lane 10 #03-98, Singapore.",
      path: "/contact",
    }),
  component: Contact,
});

function Contact() {
  return (
    <SiteLayout current="/contact">
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Contact
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Talk to the crew.
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">
            WhatsApp and the form carry the same weight. Tapping WhatsApp opens
            a message already written so you only add the building. We reply
            within 24 hours, any day.
          </p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-12 lg:grid-cols-2 sm:px-6">
        <div>
          <p className="font-bold">WhatsApp / phone</p>
          <p>
            <a className="text-teal-d" href={telUrl()}>
              {SITE.phoneDisplay}
            </a>
          </p>
          <p className="mt-4 font-bold">Email</p>
          <p>
            <a className="text-teal-d" href={mailUrl()}>
              {SITE.email}
            </a>
          </p>
          <p className="mt-4 font-bold">Office</p>
          <p>
            {SITE.addressLine}
            <br />
            {SITE.city} {SITE.postal}
            <br />
            {SITE.hours}
          </p>
          <Button asChild variant="wa" size="lg" className="mt-6">
            <a href={waUrl()} target="_blank" rel="noopener noreferrer">
              Open WhatsApp with a survey request
            </a>
          </Button>
        </div>
        <EnquiryForm />
      </section>
    </SiteLayout>
  );
}
