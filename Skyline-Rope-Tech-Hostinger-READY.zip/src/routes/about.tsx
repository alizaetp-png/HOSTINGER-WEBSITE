import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/layout";
import { CredentialBadges } from "@/components/site/badges";
import { Reveal } from "@/components/site/reveal";
import { StatCounters } from "@/components/site/stat-counters";
import { SITE, waUrl } from "@/lib/site";
import { pageHead } from "@/lib/seo";
import { Photo } from "@/components/site/photo";
import { whyPoints, homeFaqs } from "@/lib/content";

export const Route = createFileRoute("/about")({
  head: () =>
    pageHead({
      title: "About Skyline Rope Tech | Rope access Singapore",
      description:
        "Skyline Rope Tech Pte Ltd is a certified rope access contractor in Singapore. BCA PFI, bizSAFE Level 3. Client work only — no public training. 24/7.",
      path: "/about",
    }),
  component: About,
});

const promises = [
  {
    n: "01",
    title: "Diagnose the elevation, not the stain",
    body: "A ceiling mark is a symptom. We stand on the bay, test the joint and write what the water is actually doing before anyone quotes a coating.",
  },
  {
    n: "02",
    title: "Pick the access that fits the face",
    body: "Rope when it is faster and cleaner. A lift or BMU when it is safer. The method names the tool — we do not sell harnesses when a platform is the right answer.",
  },
  {
    n: "03",
    title: "Work while the building stays open",
    body: "Occupied malls, condos and plants. Exclusion is the drop zone. Floors inside keep running. Night programmes when the driveway cannot close.",
  },
  {
    n: "04",
    title: "Hand over a file the meeting can keep",
    body: "Photo log, defect schedule, PFI close-up for the PE. Warranty 1–10 years on the completed system, written into the handover.",
  },
];

function About() {
  return (
    <SiteLayout current="/about">
      <section className="relative overflow-hidden bg-ink">
        <Photo
          src="/images/web/hero-crew.jpg"
          width={1400}
          height={827}
          alt="Skyline Rope Tech rope access team briefing on a Singapore rooftop"
          className="absolute inset-0 size-full"
          priority
          sizes="100vw"
          objectPosition="center 28%"
        />
        <div
          aria-hidden
          className="absolute inset-0 bg-[linear-gradient(90deg,#163044_0%,#163044_38%,rgba(22,48,68,0.72)_58%,rgba(22,48,68,0.28)_78%,rgba(22,48,68,0.12)_100%)] max-lg:bg-[linear-gradient(180deg,rgba(22,48,68,0.45)_0%,rgba(22,48,68,0.55)_40%,#163044_100%)]"
        />
        <div className="relative mx-auto flex min-h-0 max-w-6xl items-center px-4 py-12 sm:px-6 sm:py-16 lg:min-h-[56vh]">
          <div className="max-w-xl text-primary-foreground">
            <p className="text-[0.65rem] font-extrabold tracking-[0.16em] text-teal uppercase sm:text-xs">
              Rope access contractor · Singapore
            </p>
            <h1 className="mt-3 max-w-[16ch] text-[1.75rem] leading-[1.15] font-extrabold tracking-tight sm:text-4xl md:text-5xl lg:text-6xl">
              A crew that lives on the elevation.
            </h1>
            <p className="mt-4 text-lg text-sky">
              {SITE.name}. Certified technicians. BCA Periodic Façade Inspection
              access. bizSAFE Level 3. We do not train the public. We take the
              building’s work — 24/7.
            </p>
          </div>
        </div>
      </section>

      <StatCounters />

      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-2 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Our story
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            The outside of a Singapore building is a workplace.
          </h2>
          <div className="mt-5 space-y-4 text-ink-soft">
            <p>
              Monsoon, UV, occupied floors, a council that needs a file. Most
              contractors treat that workplace as a problem of height. We treat
              it as a problem of method: who is on the line, what they can see,
              and what the building can keep when we leave.
            </p>
            <p>
              Skyline Rope Tech is a certified rope-access contractor.
              Every technician on your elevation holds a rope-access ticket. A Level
              3 supervisor owns the rescue plan before anyone leaves the roof.
              We are not a training school — certification is how the crew is qualified,
              not a course we sell.
            </p>
            <p>
              That is why MCSTs, managing agents and facilities managers call
              us for PFI close-up, seepage, reseal, paint, glass, roofs,
              cladding, signage and lighting. One crew from the first survey
              through rectification. One warranty. One WhatsApp line that
              answers every day.
            </p>
          </div>
        </Reveal>
        <Reveal>
          <Photo
            src="/images/web/about-team.jpg"
            alt="Skyline Rope Tech specialists assembled on a roof before elevation work in Singapore"
            width={1400}
            height={929}
            sizes="(max-width: 1024px) 100vw, 50vw"
            className="h-full max-h-[520px] w-full rounded-xl object-cover"
          />
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <Reveal>
            <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
              Our promises
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
              Four commitments on every elevation.
            </h2>
            <ol className="mt-10 grid gap-6 md:grid-cols-2">
              {promises.map((p) => (
                <li key={p.n} className="rounded-xl border border-line bg-card p-6">
                  <p className="text-sm font-extrabold text-teal-d">{p.n}</p>
                  <h3 className="mt-2 text-xl font-bold">{p.title}</h3>
                  <p className="mt-2 text-muted">{p.body}</p>
                </li>
              ))}
            </ol>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Reveal>
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Why owners come back
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            Honest access. A file. A line that answers.
          </h2>
          <div className="mt-8 grid gap-8 lg:grid-cols-2">
            <Photo
              src="/images/web/about-atrium.jpg"
              alt="rope access technicians on ropes inside a Singapore atrium"
              width={800}
              height={1400}
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="h-72 w-full rounded-xl object-cover sm:h-[420px]"
            />
            <div className="grid gap-5">
              {whyPoints.map((w) => (
                <div key={w.title}>
                  <h3 className="font-bold">{w.title}</h3>
                  <p className="mt-1 text-muted">{w.body}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <Reveal>
            <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
              Credentials
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight">
              What we carry onto the roof.
            </h2>
            <p className="mt-2 max-w-2xl text-muted">
              Licensed contractor. UEN {SITE.uen}. Rope access, BCA Periodic Façade
              Inspection access, bizSAFE Level 3.
            </p>
            <div className="mt-8">
              <CredentialBadges />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <Reveal>
          <h2 className="text-3xl font-bold tracking-tight">What we will not pretend</h2>
          <ul className="mt-4 grid gap-3 text-ink-soft md:grid-cols-3">
            <li className="rounded-xl border border-line bg-paper p-5">
              We are not a training centre.
            </li>
            <li className="rounded-xl border border-line bg-paper p-5">
              We will recommend a BMU or lift when it is the better access.
            </li>
            <li className="rounded-xl border border-line bg-paper p-5">
              Warranty length follows the system — 1 to 10 years — not a slogan.
            </li>
          </ul>
          <p className="mt-8 text-ink-soft">
            Office: {SITE.addressLine}, {SITE.city} {SITE.postal}. On call 24/7.
            WhatsApp {SITE.phoneDisplay}. {SITE.email}.
          </p>
        </Reveal>
      </section>

      <section className="bg-paper">
        <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-bold tracking-tight">Quick answers</h2>
          <div className="mt-6 divide-y divide-line border-y border-line">
            {homeFaqs.map((f) => (
              <details key={f.q} className="py-4">
                <summary className="cursor-pointer font-extrabold">{f.q}</summary>
                <p className="mt-2 text-muted">{f.a}</p>
              </details>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="wa" size="lg">
              <a href={waUrl()} target="_blank" rel="noopener noreferrer">
                WhatsApp the crew
              </a>
            </Button>
            <Button asChild size="lg">
              <Link to="/contact">Request a survey</Link>
            </Button>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
