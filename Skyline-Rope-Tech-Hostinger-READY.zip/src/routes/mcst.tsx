import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/layout";
import { waUrl, imgUrl } from "@/lib/site";
import { pageHead } from "@/lib/seo";
import { Photo } from "@/components/site/photo";

export const Route = createFileRoute("/mcst")({
  head: () =>
    pageHead({
      title: "MCST Rope Access & PFI Contractor Singapore | Skyline Rope Tech",
      description:
        "Rope access and BCA PFI for Singapore MCSTs. Survey, council-ready record, rectification and warranty from one rope access crew.",
      path: "/mcst",
    }),
  component: Mcst,
});

function Mcst() {
  const text =
    "Hi Skyline Rope Tech, I represent an MCST / managing agent in Singapore and need a façade survey.";
  return (
    <SiteLayout>
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            MCST façade & PFI contractor Singapore
          </p>
          <h1 className="mt-2 max-w-[16ch] text-3xl font-extrabold tracking-tight sm:text-4xl">
            Work the MCST can table on Tuesday.
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">
            A stain, a PFI deadline or a failed joint is a paper problem as much
            as a building problem. We write the method, do the elevation and
            hand over the file.
          </p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-8 px-4 py-12 lg:grid-cols-2 sm:px-6">
        <div>
          <p className="text-ink-soft">
            Chairpersons and managing agents do not buy “high-rise solutions.”
            They buy a closed leak, a passed inspection and a warranty the next
            committee can read.
          </p>
          <ul className="mt-4 list-disc space-y-1 pl-5 text-ink-soft">
            <li>Site survey with the MA or council representative</li>
            <li>PFI access and photo record for the PE</li>
            <li>Seepage, reseal, paint, glass and roof rectification</li>
            <li>1–10 year warranty on completed systems</li>
            <li>WhatsApp line that answers in 24 hours, including weekends</li>
          </ul>
          <Button asChild variant="wa" size="lg" className="mt-8">
            <a href={waUrl(text)} target="_blank" rel="noopener noreferrer">
              WhatsApp the council’s job through
            </a>
          </Button>
        </div>
        <Photo
          src={imgUrl("rope-access-crew-briefing-singapore.jpg")}
          alt="Skyline Rope Tech supervisors briefing the rope access crew before MCST elevation work in Singapore"
          width={1400}
          height={1050}
          sizes="(max-width: 1024px) 100vw, 50vw"
          className="max-h-[420px] w-full rounded-xl object-cover"
          priority
        />
      </section>
    </SiteLayout>
  );
}
