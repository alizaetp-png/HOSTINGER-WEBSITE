import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/layout";
import { services } from "@/lib/content";
import { pageHead } from "@/lib/seo";
import { Photo } from "@/components/site/photo";

export const Route = createFileRoute("/services/")({
  head: () =>
    pageHead({
      title: "Rope Access Services Singapore | Skyline Rope Tech",
      description:
        "Rope access, BCA PFI, seepage, waterproofing, painting, cleaning, glass, roofs, cladding, signage, lighting and blinds in Singapore.",
      path: "/services",
    }),
  component: ServicesIndex,
});

function ServicesIndex() {
  return (
    <SiteLayout current="/services">
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Services
          </p>
          <h1 className="mt-2 max-w-[18ch] text-3xl font-extrabold tracking-tight sm:text-4xl">
            Every job we take on the building.
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">
            Rope access is how we reach the work. The pages below are the work
            itself. Each photo is from a different Skyline job — file names and
            captions describe the work, not the camera roll.
          </p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-12 sm:grid-cols-2 sm:px-6 lg:grid-cols-3">
        {services.map((s) => (
          <Link
            key={s.slug}
            to="/services/$slug"
            params={{ slug: s.slug }}
            className="overflow-hidden rounded-xl border border-line bg-card"
          >
            <Photo
              src={s.image}
              alt={s.imageAlt}
              width={800}
              height={533}
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              className="h-48 w-full object-cover"
            />
            <div className="p-5">
              <h2 className="font-bold">{s.title}</h2>
              <p className="mt-1 text-sm text-muted">{s.lead}</p>
              <span className="mt-3 inline-block text-sm font-extrabold text-teal-d">
                Open →
              </span>
            </div>
          </Link>
        ))}
        <Link
          to="/mcst"
          className="overflow-hidden rounded-xl border border-line bg-card"
        >
          <Photo
            src="/images/rope-access-crew-briefing-singapore.jpg"
            alt="Skyline Rope Tech supervisors briefing the rope access crew on a Singapore rooftop"
            width={800}
            height={600}
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="h-48 w-full object-cover"
          />
          <div className="p-5">
            <h2 className="font-bold">MCST packages</h2>
            <p className="mt-1 text-sm text-muted">
              Council-ready survey, PFI and rectification.
            </p>
            <span className="mt-3 inline-block text-sm font-extrabold text-teal-d">
              Open →
            </span>
          </div>
        </Link>
      </section>
    </SiteLayout>
  );
}
