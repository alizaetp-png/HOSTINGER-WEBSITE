import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/layout";
import { JsonLd } from "@/components/site/json-ld";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/guides/rope-access-vs-scaffolding")({
  head: () =>
    pageHead({
      title: "Rope Access vs Scaffolding Singapore | Skyline Rope Tech",
      description:
        "When rope access beats scaffolding in Singapore — cost, time, occupied buildings and PFI close-up work.",
      path: "/guides/rope-access-vs-scaffolding",
    }),
  component: Guide,
});

function Guide() {
  return (
    <SiteLayout>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "Rope access vs scaffolding in Singapore",
          author: { "@type": "Organization", name: "Skyline Rope Tech Pte Ltd" },
          about: "Rope access compared with scaffolding for façade work",
        }}
      />
      <section className="border-b border-line bg-sky">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <p className="text-xs font-extrabold tracking-[0.16em] text-teal-d uppercase">
            Guide
          </p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight sm:text-4xl">
            Rope access vs scaffolding.
          </h1>
          <p className="mt-3 max-w-2xl text-ink-soft">
            Not a slogan. A choice that depends on the face, the ground and the
            length of the work.
          </p>
        </div>
      </section>
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <p className="text-ink-soft">
          Scaffolding wins on a long, simple elevation with space to build and a
          multi-week paint. Rope access wins when the work front is short, the
          ground is live, or the geometry blocks a tower.
        </p>
        <h2 className="mt-8 text-2xl font-bold">
          Rope access is usually right when
        </h2>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">
          <li>You need a close-up for PFI or one leaking bay</li>
          <li>The car park or drop-off cannot close</li>
          <li>Setbacks, soffits or over-water faces block a BMU</li>
          <li>Lead time matters more than covering every square metre at once</li>
        </ul>
        <h2 className="mt-8 text-2xl font-bold">
          Ask for scaffold or a BMU when
        </h2>
        <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-soft">
          <li>The whole face is being recoated for weeks</li>
          <li>Heavy materials cannot be managed from a harness</li>
          <li>The building already has a working BMU on a simple track</li>
        </ul>
        <p className="mt-6 text-ink-soft">
          We write that recommendation in the method. We do not sell ropes when
          a platform is safer or cheaper.
        </p>
      </article>
    </SiteLayout>
  );
}
