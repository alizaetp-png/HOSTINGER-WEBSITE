import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SITE, waUrl } from "@/lib/site";
import { cn } from "@/lib/utils";

const NAV: { to: "/" | "/services" | "/projects" | "/about" | "/contact"; label: string }[] = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/projects", label: "Projects" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export function SiteHeader({ current }: { current?: string }) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-card/95 backdrop-blur">
      <div className="bg-ink text-sky">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-1 px-4 py-1.5 text-[11px] leading-snug sm:flex-row sm:flex-wrap sm:items-center sm:justify-between sm:gap-1 sm:px-6 sm:text-xs">
          <span className="truncate">
            {SITE.addressLine}, {SITE.city} {SITE.postal}
          </span>
          <span className="shrink-0">
            WhatsApp {SITE.phoneDisplay} · 24/7
          </span>
        </div>
      </div>
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-1.5 sm:gap-3 sm:px-6 sm:py-2">
        <Link to="/" className="flex min-w-0 shrink items-center" aria-label={SITE.name}>
          <picture className="block">
            <source type="image/webp" srcSet="/images/opt/skyline-rope-tech-logo.webp" />
            <img
              src="/images/skyline-rope-tech-logo.png"
              alt={SITE.name}
              width={900}
              height={515}
              className="h-10 w-auto max-w-[min(100%,11.5rem)] shrink-0 sm:h-14 sm:max-w-none lg:h-16"
              decoding="async"
            />
          </picture>
        </Link>
        <nav className="hidden items-center gap-4 text-sm font-semibold text-ink-soft lg:flex xl:gap-5">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "hover:text-teal-d",
                current === item.to && "text-teal-d",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex shrink-0 items-center gap-2">
          <Button asChild variant="wa" className="hidden sm:inline-flex">
            <a href={waUrl()} target="_blank" rel="noopener noreferrer">
              WhatsApp
            </a>
          </Button>
          <Button asChild className="hidden md:inline-flex">
            <Link to="/contact">Get a survey</Link>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </div>
      {open ? (
        <nav className="grid gap-1 border-t border-line px-4 py-3 lg:hidden">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-md px-2 py-3 text-base font-semibold text-ink"
              onClick={() => setOpen(false)}
            >
              {item.label}
            </Link>
          ))}
          <a
            href={waUrl()}
            className="rounded-md px-2 py-3 text-base font-semibold text-teal-d"
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp {SITE.phoneDisplay}
          </a>
        </nav>
      ) : null}
    </header>
  );
}
