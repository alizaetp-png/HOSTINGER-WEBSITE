import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SITE, waUrl, mailUrl, telUrl } from "@/lib/site";
import { services } from "@/lib/content";

export function SiteFooter() {
  return (
    <>
      <section className="bg-ink text-primary-foreground">
        <div className="mx-auto flex max-w-6xl flex-col gap-5 px-4 py-10 sm:flex-row sm:items-center sm:justify-between sm:gap-6 sm:px-6 sm:py-12">
          <div>
            <p className="text-xs font-extrabold tracking-[0.16em] text-teal uppercase">
              24/7 reply
            </p>
            <h2 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
              Need the elevation surveyed?
            </h2>
            <p className="mt-2 max-w-xl text-sky">
              WhatsApp the crew or send the form. We answer within 24 hours.
            </p>
          </div>
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:flex-wrap">
            <Button asChild variant="wa" size="lg" className="w-full sm:w-auto">
              <a href={waUrl()} target="_blank" rel="noopener noreferrer">
                WhatsApp {SITE.phoneDisplay}
              </a>
            </Button>
            <Button asChild size="lg" className="w-full sm:w-auto">
              <Link to="/contact">Send a request</Link>
            </Button>
          </div>
        </div>
      </section>
      <footer className="bg-ink text-sky">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
          <div>
            <picture>
              <source
                type="image/webp"
                srcSet="/images/opt/skyline-rope-tech-logo-footer-on-dark.webp"
              />
              <img
                src="/images/skyline-rope-tech-logo-footer-on-dark.png"
                alt={SITE.name}
                width={900}
                height={522}
                className="mb-5 h-14 w-auto max-w-full sm:h-20 lg:h-24"
                loading="lazy"
                decoding="async"
              />
            </picture>
            <p className="text-sm">
              certified rope access for Singapore façades, roofs and
              occupied buildings. MCST and commercial. BCA Periodic Façade
              Inspection.
            </p>
            <p className="mt-3 text-sm">
              {SITE.addressLine}
              <br />
              {SITE.city} {SITE.postal}
              <br />
              <a href={telUrl()} className="underline-offset-2 hover:underline">
                {SITE.phoneDisplay}
              </a>
              <br />
              <a href={mailUrl()} className="underline-offset-2 hover:underline">
                {SITE.email}
              </a>
              <br />
              {SITE.hours}
            </p>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-primary-foreground">Work</h3>
            <ul className="grid gap-2 text-sm">
              {services.map((s) => (
                <li key={s.slug}>
                  <Link
                    to="/services/$slug"
                    params={{ slug: s.slug }}
                    className="hover:text-primary-foreground"
                  >
                    {s.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-primary-foreground">
              Company
            </h3>
            <ul className="grid gap-2 text-sm">
              <li>
                <Link to="/about" className="hover:text-primary-foreground">
                  About
                </Link>
              </li>
              <li>
                <Link to="/projects" className="hover:text-primary-foreground">
                  Projects
                </Link>
              </li>
              <li>
                <Link to="/mcst" className="hover:text-primary-foreground">
                  For MCSTs
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary-foreground">
                  All services
                </Link>
              </li>
              <li>
                <Link
                  to="/guides/rope-access-vs-scaffolding"
                  className="hover:text-primary-foreground"
                >
                  Rope vs scaffold
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary-foreground">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-primary-foreground">
                  Privacy
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-3 font-semibold text-primary-foreground">
              Credentials
            </h3>
            <p className="text-sm">Rope access · BCA / PFI · bizSAFE Level 3</p>
            <p className="mt-2 text-sm">
              1–10 year warranty on completed systems
            </p>
            <p className="mt-2 text-sm">UEN {SITE.uen}</p>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl flex-wrap justify-between gap-2 border-t border-ink-soft px-4 py-4 pb-24 text-xs sm:px-6 sm:pb-20">
          <span>
            © {new Date().getFullYear()} {SITE.name}
          </span>
          <span>Singapore rope access contractor</span>
        </div>
      </footer>
    </>
  );
}
