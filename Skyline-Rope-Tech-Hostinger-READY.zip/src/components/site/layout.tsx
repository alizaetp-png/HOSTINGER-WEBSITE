import { SiteHeader } from "./header";
import { SiteFooter } from "./footer";
import { LocalBusinessLd } from "./json-ld";
import { SITE, waUrl } from "@/lib/site";

export function SiteLayout({
  children,
  current,
}: {
  children: React.ReactNode;
  current?: string;
}) {
  return (
    <div className="flex min-h-dvh flex-col overflow-x-hidden bg-canvas text-ink">
      <LocalBusinessLd />
      <SiteHeader current={current} />
      <main className="flex-1">{children}</main>
      <SiteFooter />
      <a
        href={waUrl()}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed right-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-50 flex h-12 items-center gap-2 rounded-full bg-wa px-4 text-sm font-bold text-wa-ink shadow-soft sm:right-6 sm:bottom-6 sm:h-14"
        aria-label={`WhatsApp ${SITE.phoneDisplay}`}
      >
        <span className="text-sm">WhatsApp</span>
      </a>
    </div>
  );
}
