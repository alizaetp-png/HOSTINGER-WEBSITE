import { FormEvent, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { waUrl } from "@/lib/site";

const NEEDS = [
  "Rope access survey",
  "BCA Periodic Façade Inspection",
  "Seepage / leak",
  "Waterproofing / reseal",
  "Paint or clean",
  "Glass replacement",
  "Roofing",
  "Cladding / windows",
  "Signage or lighting",
  "Roller blinds",
  "Other",
];

export function EnquiryForm({ intent }: { intent?: string }) {
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") || "").trim();
    const phone = String(fd.get("phone") || "").trim();
    const email = String(fd.get("email") || "").trim();
    const need = String(fd.get("need") || intent || "a site survey");
    const notes = String(fd.get("notes") || "").trim();
    const lines = [
      `Hi Skyline Rope Tech, this is ${name || "a building owner"}.`,
      `I need ${need} in Singapore.`,
      notes ? `Building / notes: ${notes}` : "",
      phone ? `My number is ${phone}.` : "",
      email ? `Email: ${email}` : "",
      "Please advise on a site survey.",
    ].filter(Boolean);
    setSent(true);
    window.open(waUrl(lines.join(" ")), "_blank", "noopener,noreferrer");
  }

  return (
    <form className="grid gap-3" onSubmit={onSubmit}>
      {sent ? (
        <p className="rounded-lg bg-sky px-4 py-3 text-sm font-semibold text-ok">
          Opening WhatsApp with your message so the crew can reply.
        </p>
      ) : null}
      <div className="grid gap-1.5">
        <Label htmlFor="name">Name</Label>
        <Input id="name" name="name" required autoComplete="name" />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="phone">Phone or WhatsApp</Label>
        <Input
          id="phone"
          name="phone"
          required
          autoComplete="tel"
          inputMode="tel"
        />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="email" />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="need">What do you need?</Label>
        <select
          id="need"
          name="need"
          defaultValue={intent ?? NEEDS[0]}
          className="flex h-11 w-full rounded-md border border-line bg-card px-3.5 text-base text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:text-sm"
        >
          {NEEDS.map((n) => (
            <option key={n}>{n}</option>
          ))}
        </select>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="notes">Building / notes</Label>
        <Textarea
          id="notes"
          name="notes"
          placeholder="Estate, tower, what you can see from inside"
        />
      </div>
      <Button type="submit" size="lg">
        Send and open WhatsApp
      </Button>
    </form>
  );
}
