const BADGES = [
  {
    src: "/images/opt/badge-eq-bca-v2.webp",
    fallback: "/images/badge-eq-bca-v2.png",
    alt: "Building and Construction Authority Singapore",
    title: "BCA / PFI",
    text: "Periodic Façade Inspection access and close-up record for the Competent Person.",
  },
  {
    src: "/images/opt/badge-eq-bizsafe-v2.webp",
    fallback: "/images/badge-eq-bizsafe-v2.png",
    alt: "bizSAFE Level 3",
    title: "bizSAFE Level 3",
    text: "Workplace safety system in place before anyone leaves the roof.",
  },
] as const;

export function CredentialBadges({
  tone = "light",
}: {
  tone?: "light" | "dark";
}) {
  void tone;
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {BADGES.map((b) => (
        <article
          key={b.title}
          className="flex flex-col items-center rounded-xl border border-line bg-white p-6 text-center shadow-soft"
        >
          <div className="flex h-20 w-full items-center justify-center overflow-hidden rounded-lg bg-white">
            <picture>
              <source type="image/webp" srcSet={b.src} />
              <img
                src={b.fallback}
                alt={b.alt}
                width={480}
                height={288}
                loading="lazy"
                decoding="async"
                className="h-20 w-auto max-w-full object-contain"
              />
            </picture>
          </div>
          <p className="mt-4 font-extrabold text-ink">{b.title}</p>
          <p className="mt-1 text-sm text-muted">{b.text}</p>
        </article>
      ))}
    </div>
  );
}

export function BadgeStrip() {
  return (
    <ul className="grid max-w-md grid-cols-2 gap-2 sm:flex sm:max-w-none sm:flex-wrap sm:gap-3">
      {BADGES.map((b) => (
        <li
          key={b.title}
          className="flex h-12 w-full items-center justify-center overflow-hidden rounded-xl bg-white px-1.5 py-1.5 sm:h-14 sm:w-[7.25rem] lg:h-16 lg:w-32"
        >
          <picture className="flex h-full w-full items-center justify-center">
            <source type="image/webp" srcSet={b.src} />
            <img
              src={b.fallback}
              alt={b.alt}
              width={800}
              height={480}
              decoding="async"
              className="max-h-full max-w-full object-contain"
            />
          </picture>
        </li>
      ))}
    </ul>
  );
}
