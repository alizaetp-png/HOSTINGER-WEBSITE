import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { BadgeStrip } from "@/components/site/badges";
import { Photo } from "@/components/site/photo";
import { SITE, waUrl } from "@/lib/site";

export function HeroBanner() {
  return (
    <section className="relative overflow-hidden bg-ink">
      <Photo
        src="/images/web/hero-crew.jpg"
        width={1400}
        height={827}
        alt="certified Skyline Rope Tech crew briefing on a Singapore rooftop before rope access work"
        className="absolute inset-0 size-full"
        priority
        sizes="100vw"
        objectPosition="center 28%"
      />
      <div
        aria-hidden
        className="absolute inset-0 bg-[linear-gradient(90deg,#163044_0%,#163044_38%,rgba(22,48,68,0.72)_58%,rgba(22,48,68,0.28)_78%,rgba(22,48,68,0.12)_100%)] max-lg:bg-[linear-gradient(180deg,rgba(22,48,68,0.45)_0%,rgba(22,48,68,0.55)_40%,#163044_100%)]"
      />
      <div className="relative mx-auto flex min-h-0 max-w-6xl items-center px-4 py-10 sm:px-6 sm:py-14 lg:min-h-[82vh] lg:py-16">
        <div className="max-w-xl text-primary-foreground">
          <p className="text-[0.65rem] font-extrabold tracking-[0.16em] text-teal uppercase sm:text-xs">
            Rope access · BCA / PFI · bizSAFE Level 3
          </p>
          <h1 className="mt-3 max-w-[16ch] text-[1.75rem] leading-[1.15] font-extrabold tracking-tight break-words sm:text-4xl md:text-5xl lg:text-6xl">
            {SITE.tagline}
          </h1>
          <p className="mt-4 max-w-xl text-[0.95rem] text-sky sm:mt-5 sm:text-lg">
            Rope access for MCSTs, condos and occupied commercial buildings.
            Survey, seepage, waterproofing, paint, glass, roofs, cladding,
            signage and PFI — without a scaffold on the driveway.
          </p>
          <p className="mt-3 hidden max-w-xl text-sky sm:block">
            Certified crew. Level 3 supervisor. A written method before anyone
            leaves the roof. 1–10 year warranty on completed systems. On call
            every day.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:mt-7 sm:flex-row sm:flex-wrap">
            <Button asChild variant="wa" size="lg" className="w-full sm:w-auto">
              <a href={waUrl()} target="_blank" rel="noopener noreferrer">
                WhatsApp the crew
              </a>
            </Button>
            <Button asChild size="lg" className="w-full sm:w-auto">
              <Link to="/contact">Request a survey</Link>
            </Button>
          </div>
          <div className="mt-6 sm:mt-8">
            <BadgeStrip />
          </div>
        </div>
      </div>
    </section>
  );
}
