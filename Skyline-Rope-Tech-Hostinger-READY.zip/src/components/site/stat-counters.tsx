import { useEffect, useRef } from "react";

const STATS = [
  { end: 1500, suffix: "+", label: "Completed projects" },
  { end: 50, suffix: "+", label: "Specialists trained & certified" },
  { end: 10, prefix: "1–", suffix: " yr", label: "Warranty on completed systems" },
  { end: 24, suffix: " hr", label: "Fast reply, every day" },
] as const;

function format(end: number, prefix: string, suffix: string, n: number) {
  return `${prefix}${n.toLocaleString("en-SG")}${suffix}`;
}

function CountValue({
  end,
  prefix = "",
  suffix = "",
}: {
  end: number;
  prefix?: string;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      el.textContent = format(end, prefix, suffix, end);
      return;
    }
    let frame = 0;
    const start = performance.now();
    const duration = 1400;
    el.textContent = format(end, prefix, suffix, 0);
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - (1 - t) ** 3;
      el.textContent = format(end, prefix, suffix, Math.round(end * eased));
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [end, prefix, suffix]);

  return (
    <span ref={ref} className="tabular-nums">
      {format(end, prefix, suffix, end)}
    </span>
  );
}

export function StatCounters() {
  return (
    <div className="bg-ink text-primary-foreground">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 px-4 py-8 sm:grid-cols-4 sm:gap-6 sm:px-6 sm:py-10">
        {STATS.map((stat) => (
          <div key={stat.label}>
            <p className="text-2xl font-extrabold text-teal sm:text-3xl lg:text-4xl">
              <CountValue
                end={stat.end}
                prefix={"prefix" in stat ? stat.prefix : ""}
                suffix={stat.suffix}
              />
            </p>
            <p className="mt-1 text-xs text-sky sm:text-sm">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
