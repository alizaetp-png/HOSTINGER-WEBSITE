import { useEffect, useRef, useState } from "react";
import { processSteps } from "@/lib/content";
import { cn } from "@/lib/utils";
import { Photo } from "@/components/site/photo";

export function ProcessTimeline() {
  const rootRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const root = rootRef.current;
    const fill = fillRef.current;
    if (!root || !fill) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      fill.style.transform = "scaleY(1)";
      setActive(processSteps.length - 1);
      return;
    }

    const update = () => {
      const track = root.querySelector("[data-track]");
      if (!(track instanceof HTMLElement)) return;
      const rect = track.getBoundingClientRect();
      const vh = window.innerHeight;
      const start = vh * 0.7;
      const p = Math.min(1, Math.max(0, (start - rect.top) / rect.height));
      fill.style.transform = `scaleY(${p})`;
      const idx = Math.min(
        processSteps.length - 1,
        Math.floor(p * processSteps.length + 0.12),
      );
      setActive(idx);
    };

    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  useEffect(() => {
    const next = processSteps[active + 1];
    if (!next) return;
    const stem = next.image
      .replace(/^\/images\//, "")
      .replace(/\.(jpe?g|png|webp)$/i, "")
      .replaceAll("/", "-");
    const img = new Image();
    img.src = `/images/opt/${stem}-800.webp`;
  }, [active]);

  const current = processSteps[active] ?? processSteps[0];

  return (
    <div ref={rootRef} className="mt-8 grid items-start gap-8 sm:mt-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
      <div data-track className="relative pl-12 sm:pl-14">
        <div
          aria-hidden
          className="absolute top-5 bottom-5 left-[1.15rem] w-0.5 rounded-full bg-line sm:left-[1.35rem]"
        />
        <div
          ref={fillRef}
          aria-hidden
          className="absolute top-5 left-[1.15rem] h-[calc(100%-2.5rem)] w-0.5 origin-top rounded-full bg-teal sm:left-[1.35rem]"
          style={{ transform: "scaleY(0)" }}
        />
        <ol className="grid gap-12 sm:gap-16">
          {processSteps.map((step, i) => {
            const on = i <= active;
            return (
              <li key={step.n} className="relative min-h-28">
                <span
                  className={cn(
                    "absolute -left-12 flex size-9 items-center justify-center rounded-full border-2 text-[10px] font-extrabold transition-[background-color,color,border-color,transform] duration-200 ease-out sm:-left-14 sm:size-11 sm:text-xs",
                    on
                      ? "scale-105 border-teal bg-teal text-primary-foreground"
                      : "border-line bg-card text-muted",
                  )}
                >
                  {step.n}
                </span>
                <h3 className="text-xl font-bold">{step.title}</h3>
                <p className="mt-1 max-w-xl text-muted">{step.body}</p>
              </li>
            );
          })}
        </ol>
      </div>
      <div className="lg:sticky lg:top-28">
        <div className="relative h-52 overflow-hidden rounded-xl bg-paper shadow-soft sm:h-72 lg:h-[460px]">
          <Photo
            src={current.image}
            alt={current.imageAlt}
            width={800}
            height={800}
            sizes="(max-width: 1024px) 100vw, 480px"
            className="absolute inset-0 size-full object-cover"
            priority={active === 0}
          />
        </div>
        <p className="mt-3 text-sm font-semibold text-ink-soft">
          {current.n} · {current.title}
        </p>
      </div>
    </div>
  );
}
