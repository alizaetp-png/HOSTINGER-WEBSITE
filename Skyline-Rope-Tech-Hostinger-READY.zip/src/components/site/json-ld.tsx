import { BUSINESS_ID, SITE } from "@/lib/site";

export function JsonLd({ data }: { data: Record<string, unknown> | unknown[] }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function LocalBusinessLd() {
  return (
    <JsonLd
      data={{
        "@context": "https://schema.org",
        "@id": BUSINESS_ID,
        "@type": "GeneralContractor",
        name: SITE.name,
        image: `${SITE.url}/images/skyline-rope-tech-logo.png`,
        logo: `${SITE.url}/images/skyline-rope-tech-logo.png`,
        url: SITE.url,
        telephone: SITE.phoneTel,
        email: SITE.email,
        address: {
          "@type": "PostalAddress",
          streetAddress: SITE.addressLine,
          addressLocality: SITE.city,
          postalCode: SITE.postal,
          addressCountry: SITE.country,
        },
        areaServed: { "@type": "Country", name: "Singapore" },
        openingHoursSpecification: {
          "@type": "OpeningHoursSpecification",
          dayOfWeek: [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday",
          ],
          opens: "00:00",
          closes: "23:59",
        },
        priceRange: "$$",
        identifier: SITE.uen,
        sameAs: [`https://wa.me/${SITE.whatsappE164}`],
      }}
    />
  );
}

export function BreadcrumbLd({
  items,
}: {
  items: { name: string; path: string }[];
}) {
  return (
    <JsonLd
      data={{
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        itemListElement: items.map((item, i) => ({
          "@type": "ListItem",
          position: i + 1,
          name: item.name,
          item: `${SITE.url}${item.path === "/" ? "/" : item.path}`,
        })),
      }}
    />
  );
}
