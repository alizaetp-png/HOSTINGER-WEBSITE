import { cn } from "@/lib/utils";

type PhotoProps = {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  sizes?: string;
  objectPosition?: string;
};

function stem(src: string) {
  return src
    .replace(/^\/images\//, "")
    .replace(/\.(jpe?g|png|webp)$/i, "")
    .replaceAll("/", "-");
}

function opt(src: string, edge: 800 | 1400, ext: "webp" | "jpg") {
  return `/images/opt/${stem(src)}-${edge}.${ext}`;
}

export function Photo({
  src,
  alt,
  width = 1400,
  height = 900,
  className,
  priority = false,
  sizes = "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 400px",
  objectPosition,
}: PhotoProps) {
  return (
    <picture className={cn("block overflow-hidden", className)}>
      <source
        type="image/webp"
        srcSet={`${opt(src, 800, "webp")} 800w, ${opt(src, 1400, "webp")} 1400w`}
        sizes={sizes}
      />
      <source
        type="image/jpeg"
        srcSet={`${opt(src, 800, "jpg")} 800w, ${opt(src, 1400, "jpg")} 1400w`}
        sizes={sizes}
      />
      <img
        src={opt(src, priority ? 1400 : 800, "jpg")}
        alt={alt}
        width={width}
        height={height}
        className="size-full object-cover"
        style={objectPosition ? { objectPosition } : undefined}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        fetchPriority={priority ? "high" : "low"}
        sizes={sizes}
      />
    </picture>
  );
}
