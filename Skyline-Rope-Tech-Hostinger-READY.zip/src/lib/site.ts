export const BUSINESS_ID = "https://skylineropetech.com.sg/#business";

export const SITE = {
  name: "Skyline Rope Tech Pte Ltd",
  shortName: "Skyline Rope Tech",
  tagline: "We work the outside of Singapore’s buildings.",
  url: "https://skylineropetech.com.sg",
  phoneDisplay: "+65 8302 0783",
  phoneTel: "+6583020783",
  whatsappE164: "6583020783",
  email: "info@skylineropetech.com.sg",
  addressLine: "30 Defu Lane 10, #03-98",
  city: "Singapore",
  postal: "539211",
  country: "SG",
  uen: "202552358E",
  hours: "Open 24/7, every day",
  defaultWaText:
    "Hi Skyline Rope Tech, I would like a site survey for my building in Singapore.",
} as const;

export function waUrl(text: string = SITE.defaultWaText) {
  return `https://wa.me/${SITE.whatsappE164}?text=${encodeURIComponent(text)}`;
}

export function telUrl() {
  return `tel:${SITE.phoneTel}`;
}

export function mailUrl() {
  return `mailto:${SITE.email}`;
}

export function absUrl(path = "/") {
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${SITE.url}${p === "/" ? "/" : p}`;
}

export function imgUrl(file: string) {
  return `/images/${file}`;
}
