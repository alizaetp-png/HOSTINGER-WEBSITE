import { imgUrl } from "./site";

export type Faq = { q: string; a: string };

export type Service = {
  slug: string;
  path: string;
  nav: string;
  title: string;
  h1: string;
  metaTitle: string;
  metaDescription: string;
  kicker: string;
  lead: string;
  image: string;
  imageAlt: string;
  extraImage?: string;
  extraAlt?: string;
  body: string[];
  bullets: string[];
  faqs: Faq[];
  waText: string;
};

export const processSteps = [
  {
    n: "01",
    title: "Survey the elevation",
    body: "Site walk with the MCST, FM or PE. Drop zones, anchors and the real defect — close-up on ropes if the stain is lying.",
    image: "/images/web/step-survey.jpg",
    imageAlt:
      "Skyline Rope Tech supervisors briefing the rope access crew on a Singapore rooftop before survey",
  },
  {
    n: "02",
    title: "Issue the method",
    body: "Method statement, risk assessment and a fixed programme. Rope, gondola or lift is chosen here, with price and days on site.",
    image: "/images/web/step-method.jpg",
    imageAlt:
      "Access method chosen on site — rope, gondola or mobile lift — for a Singapore elevation",
  },
  {
    n: "03",
    title: "Work the façade",
    body: "Certified crew on the line. Driveway stays open. Occupied floors keep running.",
    image: "/images/web/step-work.jpg",
    imageAlt:
      "rope access technicians working an occupied Singapore atrium from the ropes",
  },
  {
    n: "04",
    title: "Hand over the record",
    body: "Photo log and defect schedule. For PFI, a BCA-ready condition report.",
    image: "/images/web/step-record.jpg",
    imageAlt:
      "Close-up façade record and reseal on a tiled Singapore elevation",
  },
  {
    n: "05",
    title: "Cover the work",
    body: "1–10 year warranty on the system. A 24-hour line if something needs a second look.",
    image: "/images/web/step-cover.jpg",
    imageAlt:
      "Completed external wall seepage repair on a Singapore tower, covered by Skyline warranty",
  },
];

export const services: Service[] = [
  {
    slug: "rope-access",
    path: "/services/rope-access",
    nav: "Rope access",
    title: "Rope access",
    h1: "Rope access in Singapore",
    metaTitle: "Rope Access Services Singapore | Skyline Rope Tech",
    metaDescription:
      "Certified rope access in Singapore for façade survey, repair, paint, glass and roofs. Dual-rope system, Level 3 supervisor. WhatsApp +65 8302 0783.",
    kicker: "Rope access · SS 588",
    lead: "We reach the exact bay that needs work. Dual-rope system, Level 3 supervisor, rescue plan before anyone leaves the roof.",
    image: imgUrl("irata-rope-access-atrium-singapore.jpg"),
    imageAlt:
      "rope access technicians working on atrium columns inside a Singapore mall",
    extraImage: imgUrl("rope-access-atrium-interior-singapore.jpg"),
    extraAlt:
      "Skyline Rope Tech rope access crew on ropes inside a multi-storey atrium in Singapore",
    body: [
      "Rope access is a method of working at height on two independent ropes — a working line and a backup — to accepted rope-access practice and Singapore’s SS 588. For most survey, sealant, paint and local repair scopes it is faster and cheaper than scaffolding, and the driveway stays open.",
      "Skyline Rope Tech only takes client work. We do not run a training school. Every technician on your elevation is certified; a Level 3 supervisor owns the method statement and the rescue plan.",
    ],
    bullets: [
      "Awkward geometry, setbacks, soffits or over-water faces",
      "Short work fronts — one stain, one panel, one sign",
      "Live malls, condos and plants that cannot lose the entrance",
      "PFI close-up after a drone pass",
    ],
    faqs: [
      {
        q: "Is rope access allowed in Singapore?",
        a: "Yes. Work at height sits under WSH rules. We run rope-access methods, risk assessments, permits and a written rescue plan before anyone leaves the roof.",
      },
      {
        q: "Is it cheaper than scaffolding?",
        a: "For survey, reseal, local repair and most coating scopes, yes — there is no scaffold to hire, build or strike. Full-elevation paint on a simple face can still favour a BMU or scaffold; we say so in the method.",
      },
      {
        q: "Do you train the public?",
        a: "No. We work for building owners and managers only. Certification is how the crew is qualified, not a course we sell.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need rope access for a building in Singapore. Please advise on a site survey.",
  },
  {
    slug: "bca-periodic-facade-inspection",
    path: "/services/bca-periodic-facade-inspection",
    nav: "BCA PFI",
    title: "BCA Periodic Façade Inspection",
    h1: "BCA Periodic Façade Inspection",
    metaTitle: "BCA Periodic Façade Inspection (PFI) Singapore | Skyline Rope Tech",
    metaDescription:
      "BCA Periodic Façade Inspection in Singapore by rope access. Close-up survey, photo record and rectification under one contractor.",
    kicker: "BCA · PFI",
    lead: "PFI is a statutory check on the outside of the building. We get close enough to see the defect, then we can stay and fix it.",
    image: imgUrl("bca-periodic-facade-inspection-singapore.jpg"),
    imageAlt:
      "rope access technicians inspecting a tiled high-rise façade in Singapore for BCA Periodic Façade Inspection",
    extraImage: imgUrl("tiled-facade-resealant-singapore.jpg"),
    extraAlt:
      "Rope access technician resealing a tiled façade window perimeter in Singapore",
    body: [
      "Singapore’s taller buildings must complete Periodic Façade Inspection under BCA. A Competent Person owns the report. Skyline supplies the access and the close-up record: every elevation, photographed, with defects scheduled so the PE and the council are not guessing from the ground.",
      "Because the same rope access crew can return for rectification — reseal, spalling, glass, paint — you do not hire a second contractor to chase the punch list.",
    ],
    bullets: [
      "Access method and exclusion plan for an occupied building",
      "Photographic condition record by elevation",
      "Defect schedule the PE can file",
      "Quote to close the list, if you want us to stay",
    ],
    faqs: [
      {
        q: "Do you replace the Competent Person?",
        a: "No. The PE or registered inspector remains the Competent Person. We provide rope access, close-up eyes and the photo file they need.",
      },
      {
        q: "Can you repair after PFI?",
        a: "Yes. Reseal, cladding, glass, paint and seepage rectification are core Skyline work.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need BCA Periodic Façade Inspection access for a building in Singapore.",
  },
  {
    slug: "external-wall-seepage-repair",
    path: "/services/external-wall-seepage-repair",
    nav: "Seepage",
    title: "External wall seepage repair",
    h1: "External wall seepage repair",
    metaTitle: "External Wall Seepage Repair Singapore | Skyline Rope Tech",
    metaDescription:
      "External wall seepage repair in Singapore by rope access. We trace the water path, reseal or inject, and warranty the system 1–10 years.",
    kicker: "Leak tracing",
    lead: "The stain on the ceiling is not the leak. We find the entry on the elevation and close it.",
    image: imgUrl("external-wall-seepage-repair-singapore.jpg"),
    imageAlt:
      "rope access technicians on a glass tower in Singapore carrying out external wall seepage repair",
    extraImage: imgUrl("facade-sealant-materials-singapore.jpg"),
    extraAlt:
      "Specified façade silicone sealant materials staged for Skyline Rope Tech seepage repair in Singapore",
    body: [
      "Monsoon rain finds failed sealant, hairline cracks and porous render. On a condo or tower the entry is often storeys above the stain. Rope access lets us stand on that bay, test the joint, and treat the cause — PU injection, resealant, coating — without wrapping the block in scaffold.",
      "Completed systems carry a 1–10 year warranty depending on method and substrate.",
    ],
    bullets: [
      "Trace the water path on the elevation, not the stain inside",
      "Injection, reseal and coating specified as a system",
      "Occupied units stay in use; exclusion is the drop zone",
      "Photo record for the MCST file",
    ],
    faqs: [
      {
        q: "Do you warranty seepage repairs?",
        a: "Yes. Completed systems carry a 1–10 year warranty depending on the method and substrate.",
      },
      {
        q: "Can you work on an occupied unit?",
        a: "Yes. Exclusion is limited to the drop zone. Most interiors stay in use.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I have external wall seepage at my building in Singapore and need a survey.",
  },
  {
    slug: "facade-waterproofing",
    path: "/services/facade-waterproofing",
    nav: "Waterproofing",
    title: "Waterproofing & resealant",
    h1: "Waterproofing and resealant systems",
    metaTitle: "Façade Waterproofing & Resealant Singapore | Skyline Rope Tech",
    metaDescription:
      "Façade waterproofing and resealant systems in Singapore, applied by rope access. Joints, panels and coatings treated as one system.",
    kicker: "Systems, not tubes",
    lead: "Joints, panels and coatings treated as one system — not a tube of sealant on a symptom.",
    image: imgUrl("facade-waterproofing-resealant-singapore.jpg"),
    imageAlt:
      "Overhead view of rope access technicians applying façade waterproofing and resealant on a Singapore building",
    body: [
      "A reseal that lasts in Singapore is a system: joint design, primer, the right sealant for the movement, and a coat that can take UV and rain. We apply that system from the rope on façades, parapets and junctions the gondola cannot sit on.",
      "Plaster and tanking details are part of the same trade. Roof-specific plaster and membranes sit under metal roofing and roof waterproofing.",
    ],
    bullets: [
      "Joint design, primer and specified sealant",
      "Panel, window and parapet junctions",
      "UV-stable coatings for Singapore weather",
      "1–10 year warranty on completed systems",
    ],
    faqs: [
      {
        q: "How long does a reseal last?",
        a: "A specified system, applied on a prepared joint, is typically warranted between 1 and 10 years.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need façade waterproofing and resealant for a building in Singapore.",
  },
  {
    slug: "facade-painting",
    path: "/services/facade-painting",
    nav: "Painting",
    title: "Repairs & repainting",
    h1: "Façade repairs and repainting",
    metaTitle: "High-Rise Façade Painting Singapore | Skyline Rope Tech",
    metaDescription:
      "High-rise façade repairs and repainting in Singapore. Full elevations or local making-good. Rope access or MEWP when it is the better tool.",
    kicker: "Colour and protection",
    lead: "Colour, protection and making-good on the elevation — without scaffold marks in the finish.",
    image: imgUrl("facade-repainting-singapore.jpg"),
    imageAlt:
      "Façade repairs and repainting on a Singapore building using controlled access at height",
    extraImage: imgUrl("mewp-access-singapore.jpg"),
    extraAlt:
      "Mobile elevating work platform used for façade coating where it is the better access method in Singapore",
    body: [
      "Paint on a Singapore façade is weather protection as much as appearance. We repair the substrate, then coat — full faces or the bays that failed.",
      "Rope access suits local repairs and faces a BMU cannot travel. Where a boom or lift is safer or cheaper, we say so in the method and use it. We do not sell ropes when a platform is the right tool.",
    ],
    bullets: [
      "Substrate repair before coat",
      "Full elevations or local making-good",
      "Colour match to the approved sheen",
      "Access chosen for the face, not the slogan",
    ],
    faqs: [
      {
        q: "Can you match an existing coat?",
        a: "Yes. We sample on site and coat to the approved colour and sheen.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need façade painting or repair for a building in Singapore.",
  },
  {
    slug: "facade-cleaning",
    path: "/services/facade-cleaning",
    nav: "Cleaning",
    title: "Façade cleaning",
    h1: "External façade cleaning",
    metaTitle: "High-Rise Façade Cleaning Singapore | Skyline Rope Tech",
    metaDescription:
      "High-rise façade cleaning in Singapore by rope access — glass, metal and painted faces. Small footprint on the ground.",
    kicker: "Glass, metal, paint",
    lead: "Glass, metal and paint cleaned from the rope. Small footprint on the ground.",
    image: imgUrl("high-rise-facade-cleaning-singapore.jpg"),
    imageAlt:
      "rope access technicians cleaning a high-rise façade at night in Singapore",
    extraImage: imgUrl("rope-access-building-cleaning-singapore.jpg"),
    extraAlt:
      "Skyline Rope Tech rope access team cleaning an occupied commercial façade in Singapore",
    body: [
      "Cleaning is often the first time a council sees the elevation properly. We wash glass, metal and painted faces, report defects as we pass, and can quote reseal or paint from the same drop.",
    ],
    bullets: [
      "Glass, composite, metal and painted render",
      "Night or occupied-hour programmes",
      "Defect notes handed over with the wash",
      "Same crew can stay for reseal or paint",
    ],
    faqs: [
      {
        q: "Do you clean windows only?",
        a: "No. Glass, composite, metal and painted render are all in scope.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need high-rise façade cleaning for a building in Singapore.",
  },
  {
    slug: "facade-glass-replacement",
    path: "/services/facade-glass-replacement",
    nav: "Glass",
    title: "Glass replacement",
    h1: "Façade glass supply and replacement",
    metaTitle: "Façade Glass Replacement Singapore | Skyline Rope Tech",
    metaDescription:
      "Façade glass supply, installation and replacement in Singapore using rope access. Failed lites lifted and glazed from the rope.",
    kicker: "Supply and glaze",
    lead: "Failed lite, blown unit or a new opening. We supply, lift and glaze from the rope.",
    image: imgUrl("facade-glass-replacement-singapore.jpg"),
    imageAlt:
      "rope access technicians replacing façade glass on a green glass high-rise in Singapore",
    extraImage: imgUrl("facade-glass-installation-singapore.jpg"),
    extraAlt:
      "Façade glass installation at height by Skyline Rope Tech in Singapore",
    body: [
      "Glass work at height is a lift, a gasket and a seal — not a scaffold tower for one pane. Skyline supplies and replaces façade glass and installs new lites where the opening already exists.",
      "Window reseal without glass change sits under cladding and windows.",
    ],
    bullets: [
      "Supply and replacement, or labour only",
      "Failed, blown or damaged lites",
      "Gasket and perimeter seal as a system",
      "Occupied floors stay in use",
    ],
    faqs: [
      {
        q: "Do you supply the glass?",
        a: "Yes. Supply and replacement, or labour only if the client issues the lite.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need façade glass replacement at a building in Singapore.",
  },
  {
    slug: "metal-roofing",
    path: "/services/metal-roofing",
    nav: "Roofing",
    title: "Roofing",
    h1: "Metal roofing and roof waterproofing",
    metaTitle: "Metal Roofing & Roof Waterproofing Singapore | Skyline Rope Tech",
    metaDescription:
      "Metal roof installation, plaster and roof waterproofing in Singapore, including pitches reached by rope access.",
    kicker: "Pitches and flashings",
    lead: "Pitches, flashings and membranes on roofs that are unsafe to treat as a flat deck.",
    image: imgUrl("metal-roofing-installation-singapore.jpg"),
    imageAlt:
      "Metal roofing installation in progress on a Singapore building by Skyline Rope Tech",
    extraImage: imgUrl("metal-roof-works-singapore.jpg"),
    extraAlt: "Metal roof works at height on a live Singapore building",
    body: [
      "We install metal roofing and waterproof plastered roofs. Rope access is used where the pitch, the edge or the plant on the roof makes a walkway the wrong tool.",
    ],
    bullets: [
      "Metal roof supply and install",
      "Flashings, ridges and edge details",
      "Roof plaster and waterproofing",
      "Work around plant and solar with a written method",
    ],
    faqs: [
      {
        q: "Do you work around solar?",
        a: "Yes, with a method that protects the array. Tell us the layout when you write.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need metal roofing or roof waterproofing in Singapore.",
  },
  {
    slug: "facade-cladding-repair",
    path: "/services/facade-cladding-repair",
    nav: "Cladding",
    title: "Cladding & windows",
    h1: "Cladding, tiles and window resealant",
    metaTitle: "Façade Cladding & Window Resealant Singapore | Skyline Rope Tech",
    metaDescription:
      "Façade cladding repair, tiled façade reseal and window resealant in Singapore by rope access.",
    kicker: "Panels and perimeters",
    lead: "Panels, tile faces and window perimeters closed so water stops travelling the joint.",
    image: imgUrl("facade-cladding-repair-singapore.jpg"),
    imageAlt:
      "rope access technicians repairing façade cladding on a high-rise in Singapore",
    body: [
      "Cladding that has walked, tiles that have lost their joint, windows that weep at the gasket — all of it is elevation work. We repair cladding, reseal tiled façades and remake window perimeters from the rope.",
    ],
    bullets: [
      "Single-panel replacement where the grid allows",
      "Tiled façade joint renewal",
      "Window perimeter reseal",
      "Photo record of each bay",
    ],
    faqs: [
      {
        q: "Can you replace a single panel?",
        a: "Often yes. That is a case where rope access beats a full scaffold.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need façade cladding or window resealant at a building in Singapore.",
  },
  {
    slug: "facade-signage-lighting",
    path: "/services/facade-signage-lighting",
    nav: "Signage & lighting",
    title: "Signage & lighting",
    h1: "Façade signage and lighting",
    metaTitle: "Façade Signage & Lighting Repair Singapore | Skyline Rope Tech",
    metaDescription:
      "Façade signage repair and lighting works at height in Singapore by rope access. Letters, boxes and fittings installed or removed.",
    kicker: "Letters and fittings",
    lead: "Letters, boxes and fittings on the face of the building — installed, repaired or removed.",
    image: imgUrl("facade-signage-repair-singapore.jpg"),
    imageAlt:
      "Rope access technician repairing high-level façade signage on Chan Brothers Building in Singapore",
    extraImage: imgUrl("facade-lighting-rope-access-singapore.jpg"),
    extraAlt:
      "rope access technician on a sculpted glass façade carrying out lighting works in Singapore",
    body: [
      "Signage and façade lighting fail at the bracket and the seal as often as at the lamp. We repair, replace and strip high-level signs and lights without a tower in the road.",
      "We install and repair. Design stays with your signage contractor if you have one.",
    ],
    bullets: [
      "High-level letter and box repair",
      "Façade lighting install and fault-find",
      "Strip-out without a road tower",
      "Seal the bracket so water does not follow it in",
    ],
    faqs: [
      {
        q: "Do you design new signs?",
        a: "We install and repair. Design stays with your signage contractor if you have one.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need façade signage or lighting works at height in Singapore.",
  },
  {
    slug: "roller-blinds",
    path: "/services/roller-blinds",
    nav: "Blinds",
    title: "Roller blinds",
    h1: "Roller blinds supply and replacement",
    metaTitle: "Roller Blinds Supply & Replacement Singapore | Skyline Rope Tech",
    metaDescription:
      "Supply and replacement of roller blinds in Singapore, including high reveals and façade openings reached by rope access.",
    kicker: "High reveals",
    lead: "Blinds that need a lift, a high reveal or a façade opening — supplied and fitted.",
    image: imgUrl("roller-blinds-replacement-singapore.jpg"),
    imageAlt:
      "Supply and replacement of large roller blinds in a Singapore hall by Skyline Rope Tech",
    body: [
      "Not every blind is a living-room rail. High reveals, glass façades and common-area openings are rope-access jobs when the floor below cannot take a tower. We supply and replace roller blinds in those conditions.",
    ],
    bullets: [
      "High-level and awkward access",
      "Supply and replacement",
      "Common-area and façade openings",
      "Can sit in the same package as other elevation work",
    ],
    faqs: [
      {
        q: "Do you only do high-level blinds?",
        a: "High-level and awkward access is the reason we are called. Standard interiors can be quoted if they sit in the same package.",
      },
    ],
    waText:
      "Hi Skyline Rope Tech, I need roller blinds supplied or replaced, including at height, in Singapore.",
  },
];

export function serviceBySlug(slug: string) {
  return services.find((s) => s.slug === slug);
}

export const homeCards = services;

export const whyPoints = [
  {
    title: "Rope access on the line. No school.",
    body: "Every technician is certified. A Level 3 supervisor owns the rescue plan. We do not sell courses — we take the building’s work.",
  },
  {
    title: "The access that fits the face.",
    body: "Rope when it is faster and cleaner. A lift or BMU when it is safer. Written in the method, not hidden in a slogan.",
  },
  {
    title: "A file the Tuesday meeting can keep.",
    body: "Photo log, defect schedule, PFI close-up for the PE. Warranty 1–10 years on the completed system.",
  },
  {
    title: "The driveway stays open.",
    body: "Occupied malls, condos and plants. Exclusion is the drop zone. Floors inside keep running.",
  },
];

export const homeFaqs: Faq[] = [
  {
    q: "Do you train the public in rope access?",
    a: "No. Skyline Rope Tech only works for building owners, MCSTs and facilities managers. Certification is how the crew is qualified, not a course we sell.",
  },
  {
    q: "Is rope access cheaper than scaffolding?",
    a: "For survey, reseal, local repair, glass, signage and most coating scopes, yes — there is no scaffold to hire, build or strike. Full-elevation paint on a simple face can still favour a BMU or scaffold; we say so in the method.",
  },
  {
    q: "Can you do BCA Periodic Façade Inspection?",
    a: "Yes. We supply rope access and the close-up photographic record the Competent Person needs. We do not replace the PE. The same crew can stay for rectification.",
  },
  {
    q: "Do you warranty the work?",
    a: "Completed systems carry a 1–10 year warranty depending on method and substrate. The length is written into the handover, not a headline.",
  },
  {
    q: "How fast do you reply?",
    a: "WhatsApp +65 8302 0783 and email info@skylineropetech.com.sg are manned 24/7. We aim to reply within 24 hours, including weekends.",
  },
  {
    q: "Do you work for MCSTs and homeowners as well as commercial?",
    a: "Yes. Same rope access crew. Homeowners and councils get a survey and a file the meeting can table. Commercial and industrial get a programme that keeps the driveway open.",
  },
];

export const projects = [
  {
    title: "External wall seepage closed on the elevation",
    tag: "Waterproofing",
    image: imgUrl("external-wall-seepage-repair-singapore.jpg"),
    alt: "Rope access seepage repair on a glass tower façade in Singapore",
  },
  {
    title: "Rope access crew on atrium ropes in an occupied mall",
    tag: "Rope access",
    image: imgUrl("irata-rope-access-atrium-singapore.jpg"),
    alt: "rope access inside a Singapore mall atrium",
  },
  {
    title: "Façade glass replaced at height",
    tag: "Glass",
    image: imgUrl("facade-glass-replacement-singapore.jpg"),
    alt: "Façade glass replacement on a Singapore high-rise",
  },
  {
    title: "Metal roofing on a live building",
    tag: "Roof",
    image: imgUrl("metal-roofing-installation-singapore.jpg"),
    alt: "Metal roofing installation in Singapore",
  },
  {
    title: "Tiled face inspected and resealed",
    tag: "PFI / tiles",
    image: imgUrl("bca-periodic-facade-inspection-singapore.jpg"),
    alt: "Tiled façade inspection in Singapore",
  },
  {
    title: "External wash from the rope",
    tag: "Cleaning",
    image: imgUrl("high-rise-facade-cleaning-singapore.jpg"),
    alt: "High-rise façade cleaning in Singapore",
  },
];
