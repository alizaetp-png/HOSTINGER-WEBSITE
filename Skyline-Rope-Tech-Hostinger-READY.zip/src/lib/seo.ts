import { absUrl, SITE } from "./site";

export function pageHead({
  title,
  description,
  path,
  preloadImage,
  image = "/og.jpg",
}: {
  title: string;
  description: string;
  path: string;
  preloadImage?: string;
  image?: string;
}) {
  const url = absUrl(path);
  const ogImage = image.startsWith("http") ? image : `${SITE.url}${image}`;
  const links: { rel: string; href: string; as?: string; type?: string }[] = [
    { rel: "canonical", href: url },
  ];
  if (preloadImage) {
    links.push({
      rel: "preload",
      href: preloadImage,
      as: "image",
      type: "image/webp",
    });
  }
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { name: "robots", content: "index,follow" },
      { name: "author", content: SITE.name },
      { name: "geo.region", content: "SG" },
      { name: "geo.placename", content: "Singapore" },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: SITE.shortName },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:url", content: url },
      { property: "og:image", content: ogImage },
      { property: "og:locale", content: "en_SG" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
      { name: "twitter:image", content: ogImage },
    ],
    links,
  };
}
