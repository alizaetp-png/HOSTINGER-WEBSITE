/**
 * Grok builder / PWA injector disabled for production Skyline Rope Tech.
 * Kept as a no-op so Nitro still loads the file without injecting branding.
 */
import { defineEventHandler } from "h3";

export default defineEventHandler(() => {
  // Passthrough — do not inject builder script, manifest, or generic OG.
});
