/**
 * Production SEO edge: robots by host, approved WordPress 301s, security headers.
 */
import { defineEventHandler, getRequestHeader, sendRedirect, setHeader } from "h3";

const PRODUCTION_HOSTS = new Set(["skylineropetech.com.sg", "www.skylineropetech.com.sg"]);

const LEGACY_REDIRECTS: Record<string, string> = {
  "/about-rope-access-company-singapore": "/about",
  "/about-rope-access-company-singapore/": "/about",
  "/contact/": "/contact",
  "/projects/": "/projects",
  "/sitemap_index.xml": "/sitemap.xml",
  "/roofing": "/services/metal-roofing",
  "/roofing/": "/services/metal-roofing",
  "/waterproofing": "/services/facade-waterproofing",
  "/waterproofing/": "/services/facade-waterproofing",
  "/painting": "/services/facade-painting",
  "/painting/": "/services/facade-painting",
  "/facade-inspection": "/services/bca-periodic-facade-inspection",
  "/facade-inspection/": "/services/bca-periodic-facade-inspection",
  "/periodic-facade-inspection": "/services/bca-periodic-facade-inspection",
  "/periodic-facade-inspection/": "/services/bca-periodic-facade-inspection",
  "/rope-access": "/services/rope-access",
  "/rope-access/": "/services/rope-access",
  "/seepage": "/services/external-wall-seepage-repair",
  "/seepage/": "/services/external-wall-seepage-repair",
};

function hostOf(event: Parameters<typeof getRequestHeader>[0]) {
  const raw =
    getRequestHeader(event, "x-forwarded-host") ||
    getRequestHeader(event, "host") ||
    "";
  return raw.split(",")[0].trim().toLowerCase().split(":")[0];
}

function isProductionHost(host: string) {
  return PRODUCTION_HOSTS.has(host);
}

function normalizePath(pathname: string) {
  if (pathname.length > 1 && pathname.endsWith("/")) {
    return pathname.slice(0, -1);
  }
  return pathname;
}

function robotsBody(production: boolean) {
  if (!production) {
    return `User-agent: *\nDisallow: /\n`;
  }
  return `User-agent: *\nAllow: /\n\nSitemap: https://skylineropetech.com.sg/sitemap.xml\n`;
}

export default defineEventHandler(async (event) => {
  const host = hostOf(event);
  const url = event.path || "/";
  const pathOnly = url.split("?")[0];
  const proto =
    getRequestHeader(event, "x-forwarded-proto") ||
    (event.node?.req?.socket as { encrypted?: boolean } | undefined)?.encrypted
      ? "https"
      : "http";

  if (pathOnly === "/robots.txt") {
    event.node.res.statusCode = 200;
    setHeader(event, "content-type", "text/plain; charset=utf-8");
    setHeader(event, "cache-control", "public, max-age=300");
    return robotsBody(isProductionHost(host));
  }

  if (isProductionHost(host) && host === "www.skylineropetech.com.sg") {
    return sendRedirect(event, `https://skylineropetech.com.sg${url}`, 301);
  }

  const dest = LEGACY_REDIRECTS[pathOnly] || LEGACY_REDIRECTS[normalizePath(pathOnly)];
  if (dest && dest !== pathOnly && dest !== normalizePath(pathOnly)) {
    const location = dest.startsWith("http")
      ? dest
      : isProductionHost(host)
        ? `https://skylineropetech.com.sg${dest}`
        : dest;
    return sendRedirect(event, location, 301);
  }

  const res = await event.node?.res;
  if (res) {
    setHeader(event, "X-Content-Type-Options", "nosniff");
    setHeader(event, "Referrer-Policy", "strict-origin-when-cross-origin");
    if (String(proto).includes("https") && isProductionHost(host)) {
      setHeader(event, "Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    if (!isProductionHost(host)) {
      setHeader(event, "X-Robots-Tag", "noindex, nofollow");
    }
  }
});
