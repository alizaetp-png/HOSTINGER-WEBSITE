/**
 * Hostinger Node.js entry file.
 * Listens on process.env.PORT (set by Hostinger) and 0.0.0.0.
 */
if (!process.env.HOST && !process.env.NITRO_HOST) {
  process.env.HOST = "0.0.0.0";
}
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = "production";
}
await import("./.output/server/index.mjs");
